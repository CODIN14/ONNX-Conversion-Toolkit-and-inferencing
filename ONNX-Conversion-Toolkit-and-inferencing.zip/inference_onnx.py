import os
import sys
import keras
import torch
import onnxruntime as rt
import numpy as np
from PIL import Image, ImageOps
from keras.models import load_model
import joblib
import tensorflow as tf
from tensorflow.keras.models import load_model
import tf2onnx
import torch
import torch.onnx

def convert_pytorch_to_onnx(pytorch_model_path, onnx_model_path):
    from pytorch_model import Net
    model = Net()
    model.load_state_dict(torch.load(pytorch_model_path, map_location=torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')))

    dummy_input = torch.randn(1, 1, 28, 28)
    torch.onnx.export(model, dummy_input, onnx_model_path,
                      export_params=True,
                      opset_version=12,
                      do_constant_folding=True,
                      input_names=['input'],
                      output_names=['output'],
                      dynamic_axes={'input': {0: 'batch_size'}, 'output': {0: 'batch_size'}})
    
    print(f"Model successfully converted to ONNX and saved at {onnx_model_path}")

def convert_keras_to_onnx(tf_model_path, onnx_model_path):
    loaded_model = tf.keras.models.load_model(tf_model_path)
    spec = (tf.TensorSpec((None, 28, 28, 1), tf.float32),)
    
    @tf.function(input_signature=spec)
    def model_func(x):
        return loaded_model(x)

    model_proto, external_tensor_storage = tf2onnx.convert.from_function(
        model_func,
        opset=12,
        output_path=onnx_model_path,
        input_signature=spec
    )

    with open(onnx_model_path, 'wb') as f:
        f.write(model_proto.SerializeToString())

    print(f"Model successfully converted to ONNX and saved at {onnx_model_path}")

def convert_tensorflow_to_onnx(tf_model_path, onnx_model_path):
    import tf2onnx
    loaded_model = tf.keras.models.load_model(tf_model_path)
    spec = (tf.TensorSpec((None, 28, 28, 1), tf.float32),)
    
    @tf.function(input_signature=spec)
    def model_func(x):
        return loaded_model(x)

    model_proto, external_tensor_storage = tf2onnx.convert.from_function(
        model_func,
        opset=12,
        output_path=onnx_model_path,
        input_signature=spec
    )

    with open(onnx_model_path, 'wb') as f:
        f.write(model_proto.SerializeToString())

    print(f"Model successfully converted to ONNX and saved at {onnx_model_path}")

def get_model_input_names(onnx_model_path):
    import onnx
    model = onnx.load(onnx_model_path)
    input_names = [input.name for input in model.graph.input]
    return input_names

def preprocess_image(image_path, framework):
    img = Image.open(image_path).convert('L')
    img = ImageOps.invert(img)
    img = img.resize((28, 28))
    img = np.array(img).astype(np.float32)
    img = img / 255.0
    
    if framework == "pytorch":
        img = np.expand_dims(img, axis=0)
        img = np.expand_dims(img, axis=0)
    else:
        img = np.expand_dims(img, axis=-1)
        img = np.expand_dims(img, axis=0)
        
    return img

def run_inference(onnx_model_path, image_path, framework):
    sess = rt.InferenceSession(onnx_model_path)
    input_tensor = preprocess_image(image_path, framework)
    input_name = sess.get_inputs()[0].name
    output = sess.run(None, {input_name: input_tensor})
    predicted_digit = np.argmax(output[0])
    print("Output:", output)
    print("Predicted Digit:", predicted_digit)

def main(model_path, image_path, framework):
    onnx_model_path = 'model.onnx'

    if framework == "pytorch":
            convert_pytorch_to_onnx(model_path, onnx_model_path)
    elif framework == "keras":
            convert_keras_to_onnx(model_path, onnx_model_path)
    elif framework == "tensorflow":
            convert_tensorflow_to_onnx(model_path, onnx_model_path)
    else:
        raise ValueError("Invalid framework selected.")

    run_inference(onnx_model_path, image_path, framework)

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: python script.py <model_path> <image_path> <framework>")
        sys.exit(1)

    model_path = sys.argv[1]
    image_path = sys.argv[2]
    framework = sys.argv[3].lower()

    main(model_path, image_path, framework)



