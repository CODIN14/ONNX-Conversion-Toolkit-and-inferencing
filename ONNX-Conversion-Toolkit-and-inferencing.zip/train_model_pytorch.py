# model.py (model definition and training code)
import torch
import torch.nn as nn
import torchvision
import torchvision.transforms as transforms
from pytorch_model import Net

# Define the data normalization transform
transform = transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.1307,), (0.3081,))])

# Load the MNIST dataset
train_dataset = torchvision.datasets.MNIST('~/.pytorch/MNIST_data/', download=True, train=True, transform=transform)
test_dataset = torchvision.datasets.MNIST('~/.pytorch/MNIST_data/', download=True, train=False, transform=transform)

# Create data loaders
train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=128, shuffle=True)
test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=128, shuffle=False)

# Check if GPU is available and set device
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

# Train the model
def train_model():
    model = Net().to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.SGD(model.parameters(), lr=0.005)

    for epoch in range(20):
        model.train()
        for batch in train_loader:
            x, y = batch[0].to(device), batch[1].to(device)
            optimizer.zero_grad()
            output = model(x)
            loss = criterion(output, y)
            loss.backward()
            optimizer.step()

        # Test the model
        model.eval()
        total_correct = 0
        total_samples = 0
        with torch.no_grad():
            for batch in test_loader:
                x, y = batch[0].to(device), batch[1].to(device)
                output = model(x)
                _, predicted = torch.max(output, 1)
                total_correct += (predicted == y).sum().item()
                total_samples += y.size(0)
        
        accuracy = total_correct / total_samples
        print(f"Epoch {epoch+1}, Test Accuracy: {accuracy:.4f}")

    # Save the trained model
    torch.save(model.state_dict(), 'model.pth')

# Call the training function
train_model()